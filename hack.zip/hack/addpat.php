 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hackdatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO patient_details(patient_name, patient_address, patient_mob, bed_no, doctor_name, diagnosis, date_of_admission, date_of_discharge)
VALUES ('".$_POST["name"]."', '".$_POST["address"]."', '".$_POST["contact"]."','".$_POST["bedno"]."','".$_POST["dname"]."','".$_POST["diagnosis"]."','".$_POST["doa"]."','".$_POST["dod"]."')";

//if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
//} else {
 //   echo "Error: " . $sql . "<br>" . $conn->error;
//}

 ?>