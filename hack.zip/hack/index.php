 <?php
 function checkHeartRate($rate){
 $minrate=60;
 $maxrate=100;
 if($rate<$minrate ){
		 echo "Heart Rate Deacreasing: $rate<br>";
 }
 else if( $rate>$maxrate){
		 echo "Heart Rate Increasing: $rate<br>";
 }
 else
	 echo "Normal Heart Rate: $rate<br>";
 }
 function checkBloodPressure($sys,$dia){
 $minsys=90;
 $mindia=60;
 $maxsys=120;
 $maxdia=80;
 if($sys<$minsys||$dia<$mindia){
		 echo "LOW BP: $sys/$dia<br>";
 }
 else if ($sys>$maxsys||$dia>$maxdia){
	 echo "HIGH BP: $sys/$dia<br>";
 }
 else
	 echo "NORMAL BP: $sys/$dia<br>";
 }
  function checkOxygenContent($per){
	  $minper=95;
	  $maxper=100;
	  if($per<$minper)
		  echo "LOW Oxygen Content : $per<br>";
	  else if ($per>$maxper)
		  echo "HIGH Oxygen Content : $per<br>";
	  else 
		  echo "NORMAL Oxygen Content : $per<br>";
  }
for($i=0;$i<10;$i++){
	checkHeartRate(mt_rand(1,150));
	checkBloodPressure(mt_rand(1,150),mt_rand(1,150));
	checkOxygenContent(mt_rand(75,100));
}
echo "<a href='tel:9769502070'>Call</a>";
 ?>