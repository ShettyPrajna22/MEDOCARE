 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hackdatabase";
try{
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT username,password FROM login_details WHERE username='".$_POST["us"]."' AND password='".$_POST["pw"]."';";
$result=$conn->query($sql);
	if ($result->num_rows > 0) {
		echo "<script> window.location = 'http://localhost/hack/Main.php' </script>";
	}
	else echo "INCORRECT DETAILS";
}catch(Exception $e){System.out.println($e);}

 ?>