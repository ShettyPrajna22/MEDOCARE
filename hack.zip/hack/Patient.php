<!DOCTYPE html>
<html>
<head>
<style>
    #box{

	height:300px;
	width:400px;
	background-color:rgb(180, 180, 180);
	margin-left: 500px;
	margin-top:150px;
	border-radius: 5px;
        box-shadow: 3px 3px 5px 6px #ccc; 
}
#boxin{
	margin-top: 20px;
	margin-left:20px;
}
    #dabba{
        box-sizing:15px;
        font-size: 15px;
    }
    #sub{ 
    height:50px;
        width:100px;
        background-color: aqua;
        text-decoration-color: white;
        border-radius: 5px;
        margin-right:20px;
        color:white;
        text-emphasis: bold;
        font-size:20px;
    }

</style>
</head>
<body>
	<form method="post" >
		<div id="box" >
			<div id="boxin">
			<br><br>Bed no:&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  id="bno" name="bed" > <br><br>	
			Heart Rate:&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="heart" id="hr" > <br><br>	
			Blood Pressure:&emsp;&emsp;&emsp;&emsp;<input type="text" name="pres" id="bps" ><input type="text" name="pred" id="bpd" > <br><br>	
			Oxygen Content of blood:<input type="text" name="oxygen" id="oxy"> <br><br><br>
                <input type="button" value="submit" id="sub" onclick=<?php sendData(
				"<script>document.getElementById('bno')</script>","<script>document.getElementById('hr')</script>",
				"<script>document.getElementById('bps')</script>","<script>document.getElementById('bpd')</script>",
				"<script>document.getElementById('oxy')</script>"
				);?> >
                
		</div>
		</div>
	</form>
</body>
</html>	
<?php


function sendData($bno,$hr,$bps,$bpd,$oxy){
	echo "called";
$host    = "127.0.0.1";
$port    = 1234;
$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
$result = socket_connect($socket, $host, $port) or die("Could not connect to server\n");  
$message="".$bno.",".$hr.",".$bps.",".$bpd.",".$oxy;
socket_write($socket, $message, strlen($message)) or die("Could not send data to server\n");
socket_close($socket);
}
?>