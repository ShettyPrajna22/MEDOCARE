<!DOCTYPE html>
<html>
<head>
	<title>Doctor's GUI</title>
	<!--<link rel="apple-touch-icon" sizes="180x180" href="icon/favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="icon/favicons/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="icon/favicons/favicon-16x16.png">
	<link rel="manifest" href="icon/favicons/manifest.json">
	<link rel="mask-icon" href="icon/favicons/safari-pinned-tab.svg" color="#5bbad5">-->
	<link href="https://fonts.googleapis.com/css?family=Crimson+Text:700|Libre+Baskerville" rel="stylesheet">  
	<meta name="theme-color" content="#ffffff">

	<!--CSS links-->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<link type="text/css" rel="stylesheet" href="css/materialize.css"  media="screen,projection"/>

	<link href="css/mycss.css" rel="stylesheet">


	<!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

</head>
<body>
 <!-- Navbar goes here -->

    <!-- Page Layout here -->
    <div class="row" >

      <div class="col s12 m4 l3" style="background: white;height: 0px;"> <!-- Note that "m4 l3" was added -->
        <!-- Grey navigation panel

              This content will be:
          3-columns-wide on large screens,
          4-columns-wide on medium screens,
          12-columns-wide on small screens  -->

      </div>

      <div class="col s12 m8 l9" style="background: teal;height: 100px;width:520px;"> 
        <h1> MEDOCARE</h1>
			<!-- Modal Trigger -->
			<div style="margin-left:350px;">
  <a class="waves-effect waves-light btn modal-trigger" href="#modal2">Add Patient</a>
	</div>
  <!-- Modal Structure -->
  <div id="modal2" class="modal modal-fixed-footer" style="width:450px;margin-right: 530px; margin-top: 55px;">
    <div class="modal-content" >
      <h4>Patient Details:</h4>
      
      <div class="row">
              <form class="col s12">
                <div class="row">
                  <div class="input-field col s12">
                    <input name="name" id="icon_prefix" type="text" class="validate">
                    <label for="icon_prefix">Name</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="address" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Address</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="contact" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Contact</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="bedno" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Bed Number</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="dname" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Doctor Name</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="diagnosis" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Diagnosis</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="doa" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Date Of Admission</label>
                  </div>
                  <div class="input-field col s12">
                    <input name="doa" id="icon_telephone" type="tel" class="validate">
                    <label for="icon_telephone">Date Of Discharge</label>
                  </div>
                </div>
              </form>
            </div>
            <center><a class="waves-effect waves-light btn"> Submit </a> </center>

    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat ">Close</a>
    </div>
  </div>
          


  <ul class="collapsible" style="width:500px;">
  <?php
  $servername = "localhost";
$username = "root";
$password = "";
$dbname = "hackdatabase";
try{
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM patient_details WHERE date_of_discharge='' order by bed_no;";
$result=$conn->query($sql);
	if ($result->num_rows > 0) {
		 while($row = $result->fetch_assoc()) {
        echo " <li>
      <div class='collapsible-header'>
        Patient Name : ".$row["patient_name"]. "&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Status:<span style='color:green'> &emsp;Normal </span></div>
      <div class='collapsible-body'><span>Bed Number:". $row["bed_no"] ." <br>
                                          Diagnosis:". $row["diagnosis"]."<br>
                                          Heart Rate:". "Normal" ."<br>
                                          Blood Pressure:". "Normal" ."<br>
                                          Oxygen Content Of Blood:". "Normal"  ." 

          </span></div>
    </li>";
    }
	}
	else echo "No Patients Present";
}catch(Exception $e){System.out.println($e);}

	?>
  </ul>

     <div>
      <a class="waves-effect waves-light btn modal-trigger" href="#modal1">Modal</a>
      </div>
      <!-- Modal Structure -->
	  <div id="modal1" class="modal" style="width:380px;">
    <div class="modal-content">
     <div> <h3 style='color: red'>&emsp; EMERGENCY!! </h3></div> <br><br>
          <h4>Name: Latesh Shownkeen </h4>
          <p>  Diagnosis: Heart Failure<br> 
               Bed No: 21 <br><br>
               <b>Heart Rate: 110</b> <br>
               <b>Blood Pressure : 120/80</b><br>
               <b>Oxygen Content: 96%</b> 
          </div>
        <dv class='modal-footer'>
          <a href='#!' class='modal-action modal-close waves-effect waves-green btn-flat'>Close</a>
        </div>
    </div>
  </div>
	  
	  
	  
     <?php
	 /*
$host = "127.0.0.1";
$port = 1234;
set_time_limit(0);
$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
$result = socket_bind($socket, $host, $port) or die("Could not bind to socket\n");
$result = socket_listen($socket, 20) or die("Could not set up socket listener\n");
$run=1;
while($run==1){
$spawn = socket_accept($socket) or die("Could not accept incoming connection\n");
$input = socket_read($spawn, 2048) or die("Could not read input\n");
$pieces = explode(" ", $input);
$hr=checkHeartRate($pieces[1]);
$bp=checkBloodPressure($pieces[2],$pieces[3]);
$oxy=checkOxygenContent($pieces[4]);
if($hr==1 || $hr==-1 || $bp==-1 || $bp == 1 || $oxy==1 || $oxy==-1){
	if($hr==1)
		$hrate="HIGH";
	else if($hr==0)
		$hrate="NORMAL";
	else $hrate="LOW";
	if($bp==1)
		$brate="HIGH";
	else if($bp==0)
		$brate="NORMAL";
	else $brate="LOW";
	if($oxy==1)
		$orate="HIGH";
	else if($hr==0)
		$orate="NORMAL";
	else $orate="LOW";
	echo " <div id='modal1' class='modal modal-fixed-footer modal-trigger' style='width:450px;margin-right: 530px; margin-top: 55px;'>
        <div class='modal-content'>

          <div> <h3 style='color: red'>&emsp; EMERGENCY!! </h3></div> <br><br>
          <h4>Name: "."" ."</h4>
          <p>  Diagnosis: " .""."<br> 
               Bed No: ".$pieces[0]." <br><br>
               <b>Heart Rate: ".$hrate."</b> <br>
                                           <b> Blood Pressure : ".$brate."</b><br>
                                            <b>Oxygen Content: ".$orate."</b> 
          </div>
        <div class='modal-footer'>
          <a href='#!' class='modal-action modal-close waves-effect waves-green btn-flat'>Close</a>
        </div>
      </div>";
	

	
	
	
	
	
}
}
socket_close($spawn);
socket_close($socket);
function checkHeartRate($rate){
 $minrate=60;
 $maxrate=100;
 if($rate<$minrate ){
		 return -1;
 }
 else if( $rate>$maxrate){
		 return 1;
 }
 else
	 return 0;
 }
 function checkBloodPressure($sys,$dia){
 $minsys=90;
 $mindia=60;
 $maxsys=120;
 $maxdia=80;
 if($sys<$minsys||$dia<$mindia){
		 return -1;
 }
 else if ($sys>$maxsys||$dia>$maxdia){
	 return 1;
 }
 else
	 return 0;
 }
  function checkOxygenContent($per){
	  $minper=95;
	  $maxper=100;
	  if($per<$minper)
		  return -1;
	  else if ($per>$maxper)
		 return 1;
	  else 
		  return 0;
  }
  */
?>
              
      <br> <br>
  


    </div>

<!--Jquery And JavaScript Links-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.js"></script>

<script type="text/javascript">
  
  $(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
  });
          
</script>

</body>
</html>
