<?php
$host = "127.0.0.1";
$port = 1234;
set_time_limit(0);
$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
$result = socket_bind($socket, $host, $port) or die("Could not bind to socket\n");
$result = socket_listen($socket, 20) or die("Could not set up socket listener\n");
$run=1;
while($run==1){
$spawn = socket_accept($socket) or die("Could not accept incoming connection\n");
$input = socket_read($spawn, 2048) or die("Could not read input\n");
$pieces = explode(" ", $input);
$hr=checkHeartRate($pieces[1]);
$bp=checkBloodPressure($pieces[2],$pieces[3]);
$oxy=checkOxygenContent($pieces[4]);

}
socket_close($spawn);
socket_close($socket);
function checkHeartRate($rate){
 $minrate=60;
 $maxrate=100;
 if($rate<$minrate ){
		 return -1;
 }
 else if( $rate>$maxrate){
		 return 1;
 }
 else
	 return 0;
 }
 function checkBloodPressure($sys,$dia){
 $minsys=90;
 $mindia=60;
 $maxsys=120;
 $maxdia=80;
 if($sys<$minsys||$dia<$mindia){
		 return -1;
 }
 else if ($sys>$maxsys||$dia>$maxdia){
	 return 1;
 }
 else
	 return 0;
 }
  function checkOxygenContent($per){
	  $minper=95;
	  $maxper=100;
	  if($per<$minper)
		  return -1;
	  else if ($per>$maxper)
		 return 1;
	  else 
		  return 0;
  }
?>